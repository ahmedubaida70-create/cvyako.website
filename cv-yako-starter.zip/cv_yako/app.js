const $ = (id) => document.getElementById(id);
const fields = ["name","job","email","phone","location","summary","experience","education","skills","template"];
function updatePreview(){
  $("pName").textContent = $("name").value.trim() || "Your Name";
  $("pJob").textContent = $("job").value.trim() || "Professional title";
  const contact = [$("email").value.trim(),$("phone").value.trim(),$("location").value.trim()].filter(Boolean);
  $("pContact").textContent = contact.length ? contact.join("  •  ") : "Email address  •  Phone  •  Location";
  $("pSummary").textContent = $("summary").value.trim() || "Add a short professional profile.";
  $("pExperience").textContent = $("experience").value.trim() || "Add your work experience.";
  $("pEducation").textContent = $("education").value.trim() || "Add your education.";
  $("pSkills").innerHTML = "";
  $("skills").value.split(",").map(s=>s.trim()).filter(Boolean).forEach(skill=>{
    const tag=document.createElement("span"); tag.textContent=skill; $("pSkills").appendChild(tag);
  });
  $("cvPaper").className = "cv-paper " + $("template").value;
}
fields.forEach(id=>$(id).addEventListener("input",updatePreview));
$("template").addEventListener("change",updatePreview);
updatePreview();

function showModal(id){$(id).classList.add("show");$(id).setAttribute("aria-hidden","false")}
function hideModal(id){$(id).classList.remove("show");$(id).setAttribute("aria-hidden","true")}
document.querySelectorAll("[data-close]").forEach(btn=>btn.addEventListener("click",()=>hideModal(btn.dataset.close)));
document.querySelectorAll(".modal-backdrop").forEach(backdrop=>backdrop.addEventListener("click",e=>{if(e.target===backdrop)hideModal(backdrop.id)}));
$("payBtn").addEventListener("click",()=>showModal("paymentModal"));
$("copyNumber").addEventListener("click",async()=>{
  try{await navigator.clipboard.writeText("0700306040");$("copyNumber").textContent="Copied!";}
  catch(e){$("copyNumber").textContent="Copy unavailable";}
});
$("requestVerify").addEventListener("click",()=>{
  const tx=$("transactionId").value.trim();
  if(!tx){$("transactionId").focus();$("transactionId").style.borderColor="#ef9c75";return;}
  hideModal("paymentModal");showModal("pendingModal");
  // Intentionally no client-side success action. Connect a trusted server-side
  // MTN MoMo callback/status verification before calling unlockVerifiedDownload().
});

// Only call this after your backend verifies the transaction with the payment provider.
// Never expose provider secrets or trust a transaction ID entered by the browser.
function unlockVerifiedDownload(){
  hideModal("paymentModal");hideModal("pendingModal");showModal("successModal");
  $("downloadBtn").onclick=()=>{hideModal("successModal");window.print();};
}
window.unlockVerifiedDownload = unlockVerifiedDownload;

$("resetBtn").addEventListener("click",()=>{
  $("cvForm").reset();updatePreview();
});
