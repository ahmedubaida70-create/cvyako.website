# CV YAKO starter website

## Run on Windows
1. Extract `cv-yako-starter.zip`.
2. Open the `cv_yako` folder.
3. Double-click `index.html` to open it in Chrome.
4. Edit the form fields and choose among six CV styles.
5. Use the payment button to view MTN payment instructions.
6. After a real payment has been verified, the success state is designed to unlock browser Print / Save as PDF.

## Contact and payment details configured
- MTN Mobile Money destination: 0700306040
- WhatsApp support: 0727800165
- Email support: ahmedubaida70@gmail.com
- Displayed premium price: UGX 5,000

## Important payment limitation
This is a front-end starter, not a live MTN Mobile Money integration. It does not collect money, verify transactions, or unlock downloads based on a customer-entered transaction ID. The site deliberately shows a verification-pending message. To enable real payment confirmation, connect a trusted server-side MTN MoMo integration and verify the provider's transaction status or callback on the server. Keep API keys and secrets on the server, never in browser JavaScript.

## PDF
The download button uses the browser print dialog. Choose **Save as PDF** and A4 paper size. DOCX export, user accounts, cloud storage, and the private owner dashboard are future development stages.

## Files
- `index.html` — page structure and modals
- `styles.css` — responsive premium styling
- `app.js` — live CV preview and payment UI states
